// Truth Arc Media - Interactive Portfolio JavaScript

// Initialize AOS (Animate On Scroll)
document.addEventListener('DOMContentLoaded', function() {
    AOS.init({
        duration: 800,
        easing: 'ease-in-out',
        once: true,
        mirror: false,
        offset: 100
    });
});

// ========================================
// NAVIGATION
// ========================================
const navbar = document.getElementById('navbar');
const navToggle = document.getElementById('navToggle');
const navMenu = document.getElementById('navMenu');
const navLinks = document.querySelectorAll('.nav-link');

// Navbar scroll effect
window.addEventListener('scroll', () => {
    if (window.scrollY > 50) {
        navbar.classList.add('scrolled');
    } else {
        navbar.classList.remove('scrolled');
    }
});

// Mobile menu toggle
navToggle.addEventListener('click', () => {
    navMenu.classList.toggle('active');
    navToggle.classList.toggle('active');
});

// Close mobile menu when clicking on a link
navLinks.forEach(link => {
    link.addEventListener('click', () => {
        navMenu.classList.remove('active');
        navToggle.classList.remove('active');
    });
});

// Smooth scroll with offset for fixed navbar
navLinks.forEach(link => {
    link.addEventListener('click', (e) => {
        e.preventDefault();
        const targetId = link.getAttribute('href');
        const targetSection = document.querySelector(targetId);
        
        if (targetSection) {
            const offsetTop = targetSection.offsetTop - 80;
            window.scrollTo({
                top: offsetTop,
                behavior: 'smooth'
            });
        }
    });
});

// Highlight active nav link on scroll
function highlightNavOnScroll() {
    const sections = document.querySelectorAll('section[id]');
    const scrollY = window.pageYOffset;

    sections.forEach(section => {
        const sectionHeight = section.offsetHeight;
        const sectionTop = section.offsetTop - 100;
        const sectionId = section.getAttribute('id');
        const navLink = document.querySelector(`.nav-link[href="#${sectionId}"]`);

        if (scrollY > sectionTop && scrollY <= sectionTop + sectionHeight) {
            navLinks.forEach(link => link.classList.remove('active'));
            if (navLink) navLink.classList.add('active');
        }
    });
}

window.addEventListener('scroll', highlightNavOnScroll);

// ========================================
// HERO PARALLAX EFFECT
// ========================================
const heroImage = document.querySelector('.hero-image');

window.addEventListener('scroll', () => {
    const scrolled = window.pageYOffset;
    if (heroImage && scrolled < window.innerHeight) {
        heroImage.style.transform = `translateY(${scrolled * 0.5}px)`;
    }
});

// ========================================
// CONTACT FORM
// ========================================
const contactForm = document.getElementById('contactForm');

contactForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const formData = {
        name: document.getElementById('name').value,
        email: document.getElementById('email').value,
        phone: document.getElementById('phone').value,
        service: document.getElementById('service').value,
        message: document.getElementById('message').value
    };
    
    // Show loading state
    const submitButton = contactForm.querySelector('button[type="submit"]');
    const originalText = submitButton.innerHTML;
    submitButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Sending...';
    submitButton.disabled = true;
    
    // Simulate form submission (replace with actual API call)
    setTimeout(() => {
        // Success feedback
        submitButton.innerHTML = '<i class="fas fa-check"></i> Message Sent!';
        submitButton.style.background = '#10b981';
        
        // Reset form
        contactForm.reset();
        
        // Reset button after 3 seconds
        setTimeout(() => {
            submitButton.innerHTML = originalText;
            submitButton.disabled = false;
            submitButton.style.background = '';
        }, 3000);
        
        // Show success alert
        showNotification('Thank you! We\'ll get back to you soon.', 'success');
    }, 1500);
});

// ========================================
// NOTIFICATION SYSTEM
// ========================================
function showNotification(message, type = 'success') {
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.style.cssText = `
        position: fixed;
        top: 100px;
        right: 2rem;
        background: ${type === 'success' ? '#10b981' : '#ef4444'};
        color: white;
        padding: 1rem 2rem;
        border-radius: 8px;
        box-shadow: 0 4px 16px rgba(0, 0, 0, 0.2);
        z-index: 10000;
        animation: slideInRight 0.4s ease;
    `;
    notification.innerHTML = `
        <i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'}"></i>
        ${message}
    `;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.style.animation = 'slideOutRight 0.4s ease';
        setTimeout(() => notification.remove(), 400);
    }, 3000);
}

// Add notification animations
const style = document.createElement('style');
style.innerHTML = `
    @keyframes slideInRight {
        from {
            transform: translateX(400px);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOutRight {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(400px);
            opacity: 0;
        }
    }
    
    .notification {
        display: flex;
        align-items: center;
        gap: 0.75rem;
        font-weight: 500;
    }
    
    .notification i {
        font-size: 1.25rem;
    }
`;
document.head.appendChild(style);

// ========================================
// PORTFOLIO ITEMS HOVER EFFECT
// ========================================
const portfolioItems = document.querySelectorAll('.portfolio-item');

portfolioItems.forEach(item => {
    item.addEventListener('mouseenter', function() {
        this.style.zIndex = '10';
    });
    
    item.addEventListener('mouseleave', function() {
        this.style.zIndex = '1';
    });
});

// ========================================
// SERVICE CARDS ANIMATION
// ========================================
const serviceCards = document.querySelectorAll('.service-card');

serviceCards.forEach((card, index) => {
    card.addEventListener('mouseenter', function() {
        this.style.zIndex = '10';
        
        // Slight rotation effect
        const rotation = index % 2 === 0 ? '2deg' : '-2deg';
        this.style.transform = `translateY(-12px) rotate(${rotation})`;
    });
    
    card.addEventListener('mouseleave', function() {
        this.style.zIndex = '1';
        this.style.transform = 'translateY(0) rotate(0)';
    });
});

// ========================================
// INSTAGRAM ITEMS CLICK EFFECT
// ========================================
const instagramItems = document.querySelectorAll('.instagram-item');

instagramItems.forEach(item => {
    item.addEventListener('click', function() {
        // Open Instagram (replace with actual post URLs)
        window.open('https://instagram.com/trutharcmedia', '_blank');
    });
});

// ========================================
// TESTIMONIALS AUTO-SCROLL (Optional)
// ========================================
// Uncomment to enable auto-scrolling testimonials
/*
const testimonialsGrid = document.querySelector('.testimonials-grid');
let testimonialScrollPosition = 0;

function autoScrollTestimonials() {
    const maxScroll = testimonialsGrid.scrollWidth - testimonialsGrid.clientWidth;
    testimonialScrollPosition += 1;
    
    if (testimonialScrollPosition >= maxScroll) {
        testimonialScrollPosition = 0;
    }
    
    testimonialsGrid.scrollTo({
        left: testimonialScrollPosition,
        behavior: 'smooth'
    });
}

// Start auto-scroll every 3 seconds
setInterval(autoScrollTestimonials, 3000);
*/

// ========================================
// INTERSECTION OBSERVER FOR COUNTERS
// ========================================
function animateCounter(element, target, duration = 2000) {
    let current = 0;
    const increment = target / (duration / 16);
    
    const updateCounter = () => {
        current += increment;
        if (current < target) {
            element.textContent = Math.ceil(current);
            requestAnimationFrame(updateCounter);
        } else {
            element.textContent = target;
        }
    };
    
    updateCounter();
}

// ========================================
// LAZY LOADING IMAGES
// ========================================
const lazyImages = document.querySelectorAll('img[data-src]');

const imageObserver = new IntersectionObserver((entries, observer) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            const img = entry.target;
            img.src = img.dataset.src;
            img.removeAttribute('data-src');
            observer.unobserve(img);
        }
    });
});

lazyImages.forEach(img => imageObserver.observe(img));

// ========================================
// SCROLL TO TOP BUTTON (Optional)
// ========================================
function createScrollToTopButton() {
    const button = document.createElement('button');
    button.className = 'scroll-to-top';
    button.innerHTML = '<i class="fas fa-arrow-up"></i>';
    button.style.cssText = `
        position: fixed;
        bottom: 6rem;
        right: 2rem;
        width: 50px;
        height: 50px;
        background: var(--emerald);
        color: white;
        border: none;
        border-radius: 50%;
        font-size: 1.25rem;
        cursor: pointer;
        box-shadow: 0 4px 16px rgba(16, 185, 129, 0.3);
        z-index: 998;
        opacity: 0;
        pointer-events: none;
        transition: all 0.3s ease;
    `;
    
    document.body.appendChild(button);
    
    window.addEventListener('scroll', () => {
        if (window.pageYOffset > 500) {
            button.style.opacity = '1';
            button.style.pointerEvents = 'all';
        } else {
            button.style.opacity = '0';
            button.style.pointerEvents = 'none';
        }
    });
    
    button.addEventListener('click', () => {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    });
    
    button.addEventListener('mouseenter', function() {
        this.style.background = 'var(--emerald-dark)';
        this.style.transform = 'scale(1.1)';
    });
    
    button.addEventListener('mouseleave', function() {
        this.style.background = 'var(--emerald)';
        this.style.transform = 'scale(1)';
    });
}

// Initialize scroll to top button
createScrollToTopButton();

// ========================================
// TEAM CARD ENHANCED ANIMATION
// ========================================
const teamCards = document.querySelectorAll('.team-card');

teamCards.forEach(card => {
    card.addEventListener('mouseenter', function() {
        const teamImage = this.querySelector('.team-image img');
        teamImage.style.filter = 'grayscale(0)';
    });
    
    card.addEventListener('mouseleave', function() {
        const teamImage = this.querySelector('.team-image img');
        teamImage.style.filter = 'grayscale(0)';
    });
});

// ========================================
// PROCESS TIMELINE ANIMATION
// ========================================
const processSteps = document.querySelectorAll('.process-step');

const processObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.opacity = '1';
            entry.target.style.transform = 'translateX(0)';
        }
    });
}, { threshold: 0.2 });

processSteps.forEach((step, index) => {
    step.style.opacity = '0';
    step.style.transform = index % 2 === 0 ? 'translateX(-50px)' : 'translateX(50px)';
    step.style.transition = 'all 0.8s ease';
    processObserver.observe(step);
});

// ========================================
// CURSOR TRAIL EFFECT (Optional Premium Feature)
// ========================================
function createCursorTrail() {
    const coords = { x: 0, y: 0 };
    const circles = document.querySelectorAll('.cursor-circle');
    
    if (circles.length === 0) {
        // Create cursor circles
        for (let i = 0; i < 10; i++) {
            const circle = document.createElement('div');
            circle.className = 'cursor-circle';
            circle.style.cssText = `
                position: fixed;
                width: ${8 - i * 0.5}px;
                height: ${8 - i * 0.5}px;
                border-radius: 50%;
                background: rgba(16, 185, 129, ${0.5 - i * 0.05});
                pointer-events: none;
                z-index: 9999;
                transition: transform 0.1s ease;
            `;
            document.body.appendChild(circle);
        }
    }
    
    const circles2 = document.querySelectorAll('.cursor-circle');
    
    window.addEventListener('mousemove', (e) => {
        coords.x = e.clientX;
        coords.y = e.clientY;
    });
    
    function animateCircles() {
        let x = coords.x;
        let y = coords.y;
        
        circles2.forEach((circle, index) => {
            circle.style.left = x - 4 + 'px';
            circle.style.top = y - 4 + 'px';
            circle.style.transform = `scale(${(circles2.length - index) / circles2.length})`;
            
            const nextCircle = circles2[index + 1] || circles2[0];
            x += (nextCircle.offsetLeft - x) * 0.3;
            y += (nextCircle.offsetTop - y) * 0.3;
        });
        
        requestAnimationFrame(animateCircles);
    }
    
    animateCircles();
}

// Enable cursor trail on desktop only
if (window.innerWidth > 768) {
    // Uncomment to enable cursor trail effect
    // createCursorTrail();
}

// ========================================
// PAGE LOAD ANIMATION
// ========================================
window.addEventListener('load', () => {
    document.body.style.opacity = '0';
    document.body.style.transition = 'opacity 0.5s ease';
    
    setTimeout(() => {
        document.body.style.opacity = '1';
    }, 100);
});

// ========================================
// PERFORMANCE OPTIMIZATION
// ========================================
// Debounce function for scroll events
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Optimize scroll events
window.addEventListener('scroll', debounce(() => {
    highlightNavOnScroll();
}, 100));

console.log('🎨 Truth Arc Media - Portfolio Loaded Successfully!');
console.log('💚 Premium Creative Digital Agency');

// ========================================
// FEATURED VIDEO SHOWCASE INTERACTIONS
// ========================================
document.addEventListener('DOMContentLoaded', function() {
    const heroVideo = document.querySelector('.hero-video');
    const videoWrapper = document.querySelector('.video-wrapper');
    
    if (heroVideo && videoWrapper) {
        // Play/Pause on hover (Desktop)
        if (window.innerWidth > 768) {
            videoWrapper.addEventListener('mouseenter', () => {
                heroVideo.play();
            });
        }
        
        // Pause video when out of viewport
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (!entry.isIntersecting) {
                    heroVideo.pause();
                } else if (window.innerWidth > 768) {
                    heroVideo.play();
                }
            });
        }, {
            threshold: 0.5
        });
        
        observer.observe(videoWrapper);
        
        // Click to play/pause on mobile
        if (window.innerWidth <= 768) {
            videoWrapper.addEventListener('click', () => {
                if (heroVideo.paused) {
                    heroVideo.play();
                } else {
                    heroVideo.pause();
                }
            });
        }
    }
});
