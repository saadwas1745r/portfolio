import { Hono } from 'hono'
import { cors } from 'hono/cors'
import { serveStatic } from 'hono/cloudflare-workers'

const app = new Hono()

// Enable CORS for API routes
app.use('/api/*', cors())

// Serve static files from public/static directory
app.use('/static/*', serveStatic({ root: './public' }))

// Main route with full portfolio HTML
app.get('/', (c) => {
  return c.html(`
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Truth Arc Media - Creative Digital Agency</title>
        <meta name="description" content="Truth Arc Media is a bold, cinematic creative agency specializing in graphic design, video editing, reels, motion graphics, and social media management.">
        
        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;600;700;900&family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
        
        <!-- Font Awesome Icons -->
        <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css" rel="stylesheet">
        
        <!-- AOS Animation Library -->
        <link href="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.css" rel="stylesheet">
        
        <!-- Custom Styles -->
        <link href="/static/css/styles.css" rel="stylesheet">
    </head>
    <body>
        <!-- Navigation -->
        <nav class="navbar" id="navbar">
            <div class="container nav-container">
                <a href="#home" class="nav-logo">
                    <img src="/static/images/truth-arc-logo.png" alt="Truth Arc Media" class="logo-image">
                </a>
                <button class="nav-toggle" id="navToggle">
                    <span></span>
                    <span></span>
                    <span></span>
                </button>
                <ul class="nav-menu" id="navMenu">
                    <li><a href="#home" class="nav-link">Home</a></li>
                    <li><a href="#about" class="nav-link">About</a></li>
                    <li><a href="#services" class="nav-link">Services</a></li>
                    <li><a href="#portfolio" class="nav-link">Work</a></li>
                    <li><a href="#process" class="nav-link">Process</a></li>
                    <li><a href="#team" class="nav-link">Team</a></li>
                    <li><a href="#testimonials" class="nav-link">Testimonials</a></li>
                    <li><a href="#contact" class="nav-link nav-cta">Contact</a></li>
                </ul>
            </div>
        </nav>

        <!-- Hero Section -->
        <section class="hero" id="home">
            <div class="hero-background">
                <img src="https://images.unsplash.com/photo-1492691527719-9d1e07e534b4?q=80&w=2071&auto=format&fit=crop" alt="Creative Studio" class="hero-image">
                <div class="hero-overlay"></div>
            </div>
            <div class="container hero-content">
                <div class="hero-text" data-aos="fade-up" data-aos-duration="1000">
                    <h1 class="hero-title">
                        Crafting Stories<br>
                        <span class="gradient-text">That Inspire</span>
                    </h1>
                    <p class="hero-subtitle">
                        Bold. Cinematic. Unforgettable. We transform your vision into premium digital experiences that captivate and convert.
                    </p>
                    <div class="hero-buttons">
                        <a href="#contact" class="btn btn-primary">Start Your Project</a>
                        <a href="#portfolio" class="btn btn-secondary">View Our Work</a>
                    </div>
                </div>
                
                <!-- Vision Card -->
                <div class="vision-card" data-aos="fade-left" data-aos-delay="200">
                    <div class="vision-icon">
                        <i class="fas fa-lightbulb"></i>
                    </div>
                    <h3>Our Vision</h3>
                    <p>Breaking the cycle, one frame at a time.</p>
                </div>
            </div>
            
            <!-- Scroll Indicator -->
            <div class="scroll-indicator">
                <div class="scroll-mouse"></div>
                <span>Scroll to explore</span>
            </div>
        </section>

        <!-- About Section -->
        <section class="about-section" id="about">
            <div class="container">
                <div class="about-grid">
                    <div class="about-image" data-aos="fade-right">
                        <img src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?q=80&w=2070&auto=format&fit=crop" alt="Our Team at Work">
                        <div class="about-image-overlay"></div>
                    </div>
                    
                    <div class="about-content" data-aos="fade-left">
                        <span class="section-label">Who We Are</span>
                        <h2 class="section-title">Redefining Creative Excellence</h2>
                        <p class="about-text">
                            Truth Arc Media is a boutique creative agency specializing in high-impact visual storytelling. From stunning graphics to cinematic video production, we craft content that doesn't just look good—it performs.
                        </p>
                        <p class="about-text">
                            With a lean three-member core team, we combine speed, innovation, and meticulous attention to detail. We don't just deliver projects—we deliver results that elevate your brand.
                        </p>
                        
                        <div class="why-choose">
                            <h3>Why Choose Us?</h3>
                            <ul class="benefits-list">
                                <li data-aos="fade-up" data-aos-delay="100">
                                    <i class="fas fa-check-circle"></i>
                                    <div>
                                        <strong>Premium Quality</strong>
                                        <span>Cinema-grade production values</span>
                                    </div>
                                </li>
                                <li data-aos="fade-up" data-aos-delay="200">
                                    <i class="fas fa-check-circle"></i>
                                    <div>
                                        <strong>Fast Turnaround</strong>
                                        <span>Agile team, rapid delivery</span>
                                    </div>
                                </li>
                                <li data-aos="fade-up" data-aos-delay="300">
                                    <i class="fas fa-check-circle"></i>
                                    <div>
                                        <strong>Strategic Approach</strong>
                                        <span>Data-driven creative decisions</span>
                                    </div>
                                </li>
                                <li data-aos="fade-up" data-aos-delay="400">
                                    <i class="fas fa-check-circle"></i>
                                    <div>
                                        <strong>Personalized Service</strong>
                                        <span>Direct access to our core team</span>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Services Section -->
        <section class="services-section" id="services">
            <div class="container">
                <div class="section-header" data-aos="fade-up">
                    <span class="section-label">What We Do</span>
                    <h2 class="section-title">Our Services</h2>
                    <p class="section-subtitle">Comprehensive creative solutions tailored to your brand's needs</p>
                </div>
                
                <div class="services-grid">
                    <div class="service-card" data-aos="zoom-in" data-aos-delay="100">
                        <div class="service-image">
                            <img src="https://images.unsplash.com/photo-1626785774573-4b799315345d?q=80&w=2071&auto=format&fit=crop" alt="Graphic Design">
                            <div class="service-overlay"></div>
                        </div>
                        <div class="service-icon">
                            <i class="fas fa-palette"></i>
                        </div>
                        <h3>Graphic Designing</h3>
                        <p>Stunning visuals that capture attention and communicate your brand's essence</p>
                    </div>
                    
                    <div class="service-card" data-aos="zoom-in" data-aos-delay="150">
                        <div class="service-image">
                            <img src="https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?q=80&w=2070&auto=format&fit=crop" alt="Reels Editing">
                            <div class="service-overlay"></div>
                        </div>
                        <div class="service-icon">
                            <i class="fas fa-mobile-alt"></i>
                        </div>
                        <h3>Reels Editing</h3>
                        <p>Viral-worthy short-form content optimized for Instagram, TikTok, and YouTube Shorts</p>
                    </div>
                    
                    <div class="service-card" data-aos="zoom-in" data-aos-delay="200">
                        <div class="service-image">
                            <img src="https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?q=80&w=2070&auto=format&fit=crop" alt="Video Editing">
                            <div class="service-overlay"></div>
                        </div>
                        <div class="service-icon">
                            <i class="fas fa-video"></i>
                        </div>
                        <h3>Video Editing</h3>
                        <p>Cinematic storytelling with professional color grading and seamless transitions</p>
                    </div>
                    
                    <div class="service-card" data-aos="zoom-in" data-aos-delay="250">
                        <div class="service-image">
                            <img src="https://images.unsplash.com/photo-1551650975-87deedd944c3?q=80&w=2074&auto=format&fit=crop" alt="Motion Graphics">
                            <div class="service-overlay"></div>
                        </div>
                        <div class="service-icon">
                            <i class="fas fa-magic"></i>
                        </div>
                        <h3>Motion Graphics</h3>
                        <p>Dynamic animations that bring your brand to life with modern visual effects</p>
                    </div>
                    
                    <div class="service-card" data-aos="zoom-in" data-aos-delay="300">
                        <div class="service-image">
                            <img src="https://images.unsplash.com/photo-1455390582262-044cdead277a?q=80&w=2073&auto=format&fit=crop" alt="Content Research">
                            <div class="service-overlay"></div>
                        </div>
                        <div class="service-icon">
                            <i class="fas fa-search"></i>
                        </div>
                        <h3>Content Research</h3>
                        <p>Data-driven insights to fuel authentic, engaging, and trend-relevant content</p>
                    </div>
                    
                    <div class="service-card" data-aos="zoom-in" data-aos-delay="350">
                        <div class="service-image">
                            <img src="https://images.unsplash.com/photo-1455390582262-044cdead277a?q=80&w=2073&auto=format&fit=crop" alt="Script Writing">
                            <div class="service-overlay"></div>
                        </div>
                        <div class="service-icon">
                            <i class="fas fa-pen-fancy"></i>
                        </div>
                        <h3>Script Writing</h3>
                        <p>Compelling narratives crafted to engage, inspire, and drive action</p>
                    </div>
                    
                    <div class="service-card" data-aos="zoom-in" data-aos-delay="400">
                        <div class="service-image">
                            <img src="https://images.unsplash.com/photo-1611926653670-e0caa3e3c6f5?q=80&w=2070&auto=format&fit=crop" alt="Social Media Management">
                            <div class="service-overlay"></div>
                        </div>
                        <div class="service-icon">
                            <i class="fas fa-share-alt"></i>
                        </div>
                        <h3>Social Media Management</h3>
                        <p>Strategic content calendars and community engagement that grow your brand</p>
                    </div>
                    
                    <div class="service-card" data-aos="zoom-in" data-aos-delay="450">
                        <div class="service-image">
                            <img src="https://images.unsplash.com/photo-1626785774625-0b1c2c4eab67?q=80&w=2071&auto=format&fit=crop" alt="Poster Design">
                            <div class="service-overlay"></div>
                        </div>
                        <div class="service-icon">
                            <i class="fas fa-image"></i>
                        </div>
                        <h3>Poster Design</h3>
                        <p>Eye-catching promotional materials that make your message impossible to ignore</p>
                    </div>
                </div>
            </div>
        </section>

        <!-- Portfolio Section -->
        <!-- Our Work Section - Cinematic Portfolio -->
        <section class="balanced-work-page" id="portfolio">
            <!-- SECTION 1 — HERO INTRO (65vh, centered, symmetric) -->
            <div class="balanced-hero">
                <div class="balanced-hero-content">
                    <h1 class="balanced-title">Our Work</h1>
                    <p class="balanced-subtitle">A showcase of creative excellence and strategic storytelling that delivers measurable results</p>
                </div>
            </div>

            <!-- SECTION 2 — FEATURED VIDEO (FULL-WIDTH, CENTERED, LARGE VERTICAL SPACE) -->
            <div class="balanced-featured-video">
                <div class="balanced-video-wrapper">
                    <div class="balanced-video-box" data-aos="fade-up">
                        <video 
                            class="balanced-video-player" 
                            autoplay 
                            muted 
                            loop 
                            playsinline
                            poster="https://images.unsplash.com/photo-1558618666-fcd25c85cd64?q=80&w=2071&auto=format&fit=crop"
                        >
                            <source src="https://assets.mixkit.co/videos/preview/mixkit-abstract-digital-art-with-bright-colors-41361-large.mp4" type="video/mp4">
                        </video>
                        
                        <div class="balanced-video-overlay">
                            <span class="overlay-badge">FEATURED CASE STUDY</span>
                            <h2 class="overlay-title">Brand Revolution Campaign</h2>
                            <p class="overlay-client">TechStart Inc.</p>
                            <p class="overlay-description">A motion-driven campaign redefining digital brand presence</p>
                            <a href="#contact" class="overlay-cta">Watch Full Case Study</a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- SECTION 3 — BALANCED 3-COLUMN MOSAIC GRID -->
            <div class="balanced-mosaic">
                <div class="balanced-grid-container">
                    <div class="balanced-grid">
                        
                        <!-- LEFT COLUMN: Tall + Medium -->
                        <!-- Event Highlight Reel - Tall Card (spans row 1-3) -->
                        <article class="balanced-card tall-left" data-aos="fade-up" data-aos-delay="100">
                            <div class="balanced-card-image" style="background-image: url('https://images.unsplash.com/photo-1492684223066-81342ee5ff30?q=80&w=2070&auto=format&fit=crop');"></div>
                            <div class="balanced-card-content">
                                <span class="balanced-tag">VIDEO EDITING</span>
                                <h3 class="balanced-heading">Event Highlight Reel</h3>
                                <p class="balanced-client">Summit Conference</p>
                                <p class="balanced-result">Captured the energy of a 3-day conference in 90 seconds</p>
                            </div>
                        </article>

                        <!-- CENTER COLUMN: Wide (2-col span) + Compact -->
                        <!-- Product Launch Video - Wide Card (spans col 2-3, row 1-2) -->
                        <article class="balanced-card wide-center" data-aos="fade-up" data-aos-delay="200">
                            <div class="balanced-card-image" style="background-image: url('https://images.unsplash.com/photo-1558769132-cb1aea016c7b?q=80&w=2074&auto=format&fit=crop');"></div>
                            <div class="balanced-card-content">
                                <span class="balanced-tag">VIDEO PRODUCTION</span>
                                <h3 class="balanced-heading">Product Launch Video</h3>
                                <p class="balanced-client">EcoWear Fashion</p>
                                <p class="balanced-result">Minimalist video showcasing sustainable fashion</p>
                            </div>
                        </article>

                        <!-- Restaurant Brand Identity - Compact Card (col 2, row 3) -->
                        <article class="balanced-card compact-center" data-aos="fade-up" data-aos-delay="300">
                            <div class="balanced-card-image" style="background-image: url('https://images.unsplash.com/photo-1504674900247-0877df9cc836?q=80&w=2070&auto=format&fit=crop');"></div>
                            <div class="balanced-card-content">
                                <span class="balanced-tag">GRAPHIC DESIGN</span>
                                <h3 class="balanced-heading">Restaurant Brand Identity</h3>
                                <p class="balanced-client">Savory Bites</p>
                            </div>
                        </article>

                        <!-- Animated Explainer - Medium Vertical (col 3, row 3) -->
                        <article class="balanced-card medium-center" data-aos="fade-up" data-aos-delay="350">
                            <div class="balanced-card-image" style="background-image: url('https://images.unsplash.com/photo-1551650975-87deedd944c3?q=80&w=2074&auto=format&fit=crop');"></div>
                            <div class="balanced-card-content">
                                <span class="balanced-tag">ANIMATION</span>
                                <h3 class="balanced-heading">Animated Explainer Series</h3>
                                <p class="balanced-client">FinTech Solutions</p>
                            </div>
                        </article>

                        <!-- RIGHT COLUMN: Large Vertical + Medium -->
                        <!-- Social Media Takeover - Large Vertical (spans row 1-3) -->
                        <article class="balanced-card large-right accent-border" data-aos="fade-up" data-aos-delay="400">
                            <div class="balanced-card-image" style="background-image: url('https://images.unsplash.com/photo-1517836357463-d25dfeac3438?q=80&w=2070&auto=format&fit=crop');"></div>
                            <div class="balanced-card-content">
                                <span class="balanced-tag">CONTENT CREATION</span>
                                <h3 class="balanced-heading">Social Media Takeover</h3>
                                <p class="balanced-client">FitLife Studios</p>
                                <p class="balanced-metric">300% engagement increase in 90 days</p>
                                <a href="#contact" class="balanced-cta">View Project</a>
                            </div>
                        </article>

                    </div>
                </div>
            </div>
        </section>

        <!-- Process Section -->
        <section class="process-section" id="process">
            <div class="container">
                <div class="section-header" data-aos="fade-up">
                    <span class="section-label">How We Work</span>
                    <h2 class="section-title">Our Creative Process</h2>
                    <p class="section-subtitle">A proven 4-step methodology that delivers exceptional results</p>
                </div>
                
                <div class="process-timeline">
                    <div class="process-step" data-aos="fade-right" data-aos-delay="100">
                        <div class="process-number">01</div>
                        <div class="process-image">
                            <img src="https://images.unsplash.com/photo-1552664730-d307ca884978?q=80&w=2070&auto=format&fit=crop" alt="Research">
                        </div>
                        <div class="process-content">
                            <h3>Research & Discovery</h3>
                            <p>We dive deep into your brand, audience, and goals to understand what makes you unique and how to communicate it effectively.</p>
                        </div>
                    </div>
                    
                    <div class="process-connector"></div>
                    
                    <div class="process-step" data-aos="fade-left" data-aos-delay="200">
                        <div class="process-number">02</div>
                        <div class="process-image">
                            <img src="https://images.unsplash.com/photo-1558618666-fcd25c85cd64?q=80&w=2071&auto=format&fit=crop" alt="Creative Concept">
                        </div>
                        <div class="process-content">
                            <h3>Creative Concept</h3>
                            <p>Our team crafts bold, innovative concepts that align with your vision and resonate with your target audience.</p>
                        </div>
                    </div>
                    
                    <div class="process-connector"></div>
                    
                    <div class="process-step" data-aos="fade-right" data-aos-delay="300">
                        <div class="process-number">03</div>
                        <div class="process-image">
                            <img src="https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?q=80&w=2070&auto=format&fit=crop" alt="Production">
                        </div>
                        <div class="process-content">
                            <h3>Production & Editing</h3>
                            <p>From filming to final edits, we bring the concept to life with cinema-quality production and meticulous attention to detail.</p>
                        </div>
                    </div>
                    
                    <div class="process-connector"></div>
                    
                    <div class="process-step" data-aos="fade-left" data-aos-delay="400">
                        <div class="process-number">04</div>
                        <div class="process-image">
                            <img src="https://images.unsplash.com/photo-1460925895917-afdab827c52f?q=80&w=2015&auto=format&fit=crop" alt="Optimization">
                        </div>
                        <div class="process-content">
                            <h3>Optimization & Delivery</h3>
                            <p>We optimize every asset for maximum impact across platforms and deliver files ready for immediate deployment.</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Team Section -->
        <!-- Meet The Creators Section -->
        <section class="team-section" id="team">
            <div class="team-container">
                <!-- Heading Area -->
                <div class="team-header" data-aos="fade-up">
                    <h1 class="team-main-title">Meet The Creators</h1>
                    <p class="team-subtitle">The passionate minds behind every frame, every story, every success</p>
                </div>
                
                <!-- Team Member Cards -->
                <div class="team-members" data-aos="fade-up" data-aos-delay="200">
                    <!-- Member 1: Saad Waseem -->
                    <div class="team-member">
                        <div class="member-photo">
                            <img src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=2070&auto=format&fit=crop" alt="Saad Waseem - Manager">
                        </div>
                        <h3 class="member-name">Saad Waseem</h3>
                        <p class="member-role">MANAGER</p>
                        <p class="member-bio">Visionary storyteller with 8+ years crafting brand narratives that resonate</p>
                    </div>
                    
                    <!-- Member 2: Zohaib Naseem -->
                    <div class="team-member">
                        <div class="member-photo">
                            <img src="https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?q=80&w=2070&auto=format&fit=crop" alt="Zohaib Naseem - Video Editor">
                        </div>
                        <h3 class="member-name">Zohaib Naseem</h3>
                        <p class="member-role">VIDEO EDITOR</p>
                        <p class="member-bio">Animation wizard specializing in dynamic motion graphics and visual effects</p>
                    </div>
                    
                    <!-- Member 3: Sahil Asif -->
                    <div class="team-member">
                        <div class="member-photo">
                            <img src="https://images.unsplash.com/photo-1500648767791-00dcc994a43e?q=80&w=2070&auto=format&fit=crop" alt="Sahil Asif - Graphic Designer">
                        </div>
                        <h3 class="member-name">Sahil Asif</h3>
                        <p class="member-role">GRAPHIC DESIGNER</p>
                        <p class="member-bio">Post-production expert turning raw footage into cinematic masterpieces</p>
                    </div>
                </div>
                
                <!-- Bottom Description -->
                <div class="team-bottom-description" data-aos="fade-up" data-aos-delay="400">
                    <p>
                        Our three-member creative core delivers high-impact work with collaboration, speed, and innovation. 
                        We're not just a team—we're a creative force united by passion, precision, and a relentless drive 
                        to exceed expectations on every project.
                    </p>
                </div>
            </div>
            
            <!-- Floating Social Buttons -->
            <div class="floating-social">
                <a href="https://instagram.com/trutharcmedia" target="_blank" class="social-float-btn instagram-btn" aria-label="Instagram">
                    <i class="fab fa-instagram"></i>
                </a>
                <a href="https://wa.me/923288903232" target="_blank" class="social-float-btn whatsapp-btn" aria-label="WhatsApp">
                    <i class="fab fa-whatsapp"></i>
                </a>
            </div>
        </section>

        <!-- Testimonials Section -->
        <section class="testimonials-section" id="testimonials">
            <div class="container">
                <div class="section-header" data-aos="fade-up">
                    <span class="section-label">Client Love</span>
                    <h2 class="section-title">What Our Clients Say</h2>
                    <p class="section-subtitle">Real feedback from brands we've helped transform</p>
                </div>
                
                <div class="testimonials-grid">
                    <div class="testimonial-card" data-aos="fade-up" data-aos-delay="100">
                        <div class="testimonial-rating">
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                        </div>
                        <p class="testimonial-text">
                            "Truth Arc Media transformed our brand presence completely. Their cinematic approach to our product videos increased our engagement by 340%. Absolutely phenomenal work!"
                        </p>
                        <div class="testimonial-author">
                            <img src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=2070&auto=format&fit=crop" alt="Sarah Martinez">
                            <div class="author-info">
                                <h4>Sarah Martinez</h4>
                                <span>CEO, LuxeLife Brands</span>
                                <a href="https://instagram.com/sarahmartinez" target="_blank" class="author-instagram">
                                    <i class="fab fa-instagram"></i> @sarahmartinez
                                </a>
                            </div>
                        </div>
                    </div>
                    
                    <div class="testimonial-card" data-aos="fade-up" data-aos-delay="150">
                        <div class="testimonial-rating">
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                        </div>
                        <p class="testimonial-text">
                            "Working with this team felt like having an in-house creative department. Fast, responsive, and always exceeding expectations. Our Instagram grew from 5K to 50K in 4 months!"
                        </p>
                        <div class="testimonial-author">
                            <img src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?q=80&w=2070&auto=format&fit=crop" alt="Michael Park">
                            <div class="author-info">
                                <h4>Michael Park</h4>
                                <span>Founder, TechFlow Solutions</span>
                                <a href="https://instagram.com/michaelpark" target="_blank" class="author-instagram">
                                    <i class="fab fa-instagram"></i> @michaelpark
                                </a>
                            </div>
                        </div>
                    </div>
                    
                    <div class="testimonial-card" data-aos="fade-up" data-aos-delay="200">
                        <div class="testimonial-rating">
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                        </div>
                        <p class="testimonial-text">
                            "The quality is unmatched. Every frame, every transition, every graphic—pure perfection. They don't just deliver content; they deliver art that sells."
                        </p>
                        <div class="testimonial-author">
                            <img src="https://images.unsplash.com/photo-1580489944761-15a19d654956?q=80&w=2061&auto=format&fit=crop" alt="Emma Thompson">
                            <div class="author-info">
                                <h4>Emma Thompson</h4>
                                <span>Marketing Director, GreenEarth Co.</span>
                                <a href="https://instagram.com/emmathompson" target="_blank" class="author-instagram">
                                    <i class="fab fa-instagram"></i> @emmathompson
                                </a>
                            </div>
                        </div>
                    </div>
                    
                    <div class="testimonial-card" data-aos="fade-up" data-aos-delay="250">
                        <div class="testimonial-rating">
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                        </div>
                        <p class="testimonial-text">
                            "I've worked with dozens of agencies, but Truth Arc Media stands out. Their creative process is seamless, and the final results always exceed the brief. Highly recommended!"
                        </p>
                        <div class="testimonial-author">
                            <img src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=2070&auto=format&fit=crop" alt="David Kumar">
                            <div class="author-info">
                                <h4>David Kumar</h4>
                                <span>Creative Lead, BoldBrand Agency</span>
                                <a href="https://instagram.com/davidkumar" target="_blank" class="author-instagram">
                                    <i class="fab fa-instagram"></i> @davidkumar
                                </a>
                            </div>
                        </div>
                    </div>
                    
                    <div class="testimonial-card" data-aos="fade-up" data-aos-delay="300">
                        <div class="testimonial-rating">
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                        </div>
                        <p class="testimonial-text">
                            "Their motion graphics elevated our product launch beyond what we imagined. The attention to detail and creative execution was flawless. We're clients for life!"
                        </p>
                        <div class="testimonial-author">
                            <img src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=2064&auto=format&fit=crop" alt="Jessica Lee">
                            <div class="author-info">
                                <h4>Jessica Lee</h4>
                                <span>Product Manager, NovaTech</span>
                                <a href="https://instagram.com/jessicalee" target="_blank" class="author-instagram">
                                    <i class="fab fa-instagram"></i> @jessicalee
                                </a>
                            </div>
                        </div>
                    </div>
                    
                    <div class="testimonial-card" data-aos="fade-up" data-aos-delay="350">
                        <div class="testimonial-rating">
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                        </div>
                        <p class="testimonial-text">
                            "From concept to delivery, every touchpoint was professional and creative. They captured our brand essence perfectly and delivered content that truly converts. Outstanding!"
                        </p>
                        <div class="testimonial-author">
                            <img src="https://images.unsplash.com/photo-1500648767791-00dcc994a43e?q=80&w=2070&auto=format&fit=crop" alt="Ryan Foster">
                            <div class="author-info">
                                <h4>Ryan Foster</h4>
                                <span>Owner, Sunset Cafe</span>
                                <a href="https://instagram.com/ryanfoster" target="_blank" class="author-instagram">
                                    <i class="fab fa-instagram"></i> @ryanfoster
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Instagram Section -->
        <section class="instagram-section" id="instagram">
            <div class="instagram-background"></div>
            <div class="container">
                <div class="section-header" data-aos="fade-up">
                    <span class="section-label">Follow Our Journey</span>
                    <h2 class="section-title">Latest From Instagram</h2>
                    <p class="section-subtitle">Behind-the-scenes, projects, and creative inspiration</p>
                </div>
                
                <div class="instagram-grid">
                    <div class="instagram-item" data-aos="zoom-in" data-aos-delay="100">
                        <img src="https://images.unsplash.com/photo-1611162616475-46b635cb6868?q=80&w=2074&auto=format&fit=crop" alt="Instagram Post 1">
                        <div class="instagram-overlay">
                            <i class="fab fa-instagram"></i>
                        </div>
                    </div>
                    
                    <div class="instagram-item" data-aos="zoom-in" data-aos-delay="150">
                        <img src="https://images.unsplash.com/photo-1626785774573-4b799315345d?q=80&w=2071&auto=format&fit=crop" alt="Instagram Post 2">
                        <div class="instagram-overlay">
                            <i class="fab fa-instagram"></i>
                        </div>
                    </div>
                    
                    <div class="instagram-item" data-aos="zoom-in" data-aos-delay="200">
                        <img src="https://images.unsplash.com/photo-1558618666-fcd25c85cd64?q=80&w=2071&auto=format&fit=crop" alt="Instagram Post 3">
                        <div class="instagram-overlay">
                            <i class="fab fa-instagram"></i>
                        </div>
                    </div>
                    
                    <div class="instagram-item" data-aos="zoom-in" data-aos-delay="250">
                        <img src="https://images.unsplash.com/photo-1551650975-87deedd944c3?q=80&w=2074&auto=format&fit=crop" alt="Instagram Post 4">
                        <div class="instagram-overlay">
                            <i class="fab fa-instagram"></i>
                        </div>
                    </div>
                    
                    <div class="instagram-item" data-aos="zoom-in" data-aos-delay="300">
                        <img src="https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?q=80&w=2070&auto=format&fit=crop" alt="Instagram Post 5">
                        <div class="instagram-overlay">
                            <i class="fab fa-instagram"></i>
                        </div>
                    </div>
                    
                    <div class="instagram-item" data-aos="zoom-in" data-aos-delay="350">
                        <img src="https://images.unsplash.com/photo-1492691527719-9d1e07e534b4?q=80&w=2071&auto=format&fit=crop" alt="Instagram Post 6">
                        <div class="instagram-overlay">
                            <i class="fab fa-instagram"></i>
                        </div>
                    </div>
                </div>
                
                <div class="instagram-cta" data-aos="fade-up" data-aos-delay="400">
                    <a href="https://instagram.com/trutharcmedia" target="_blank" class="btn btn-primary instagram-btn">
                        <i class="fab fa-instagram"></i> Follow Us on Instagram
                    </a>
                </div>
            </div>
        </section>

        <!-- Contact Section -->
        <section class="contact-section" id="contact">
            <div class="container">
                <div class="contact-grid">
                    <div class="contact-info" data-aos="fade-right">
                        <span class="section-label">Get In Touch</span>
                        <h2 class="section-title">Let's Create Something Amazing</h2>
                        <p class="contact-text">
                            Ready to elevate your brand with premium creative content? Whether you need a single project or ongoing support, we're here to bring your vision to life.
                        </p>
                        
                        <div class="contact-details">
                            <div class="contact-item">
                                <i class="fas fa-envelope"></i>
                                <div>
                                    <h4>Email Us</h4>
                                    <a href="mailto:trutharcmedia3@gmail.com">trutharcmedia3@gmail.com</a>
                                </div>
                            </div>
                            
                            <div class="contact-item">
                                <i class="fab fa-instagram"></i>
                                <div>
                                    <h4>Instagram</h4>
                                    <a href="https://instagram.com/trutharcmedia" target="_blank">@trutharcmedia</a>
                                </div>
                            </div>
                            
                            <div class="contact-item">
                                <i class="fas fa-phone-alt"></i>
                                <div>
                                    <h4>WhatsApp</h4>
                                    <a href="https://wa.me/923288903232" target="_blank">+92 328 8903232</a>
                                </div>
                            </div>
                        </div>
                        
                        <div class="contact-map" data-aos="fade-up" data-aos-delay="200">
                            <img src="https://images.unsplash.com/photo-1524661135-423995f22d0b?q=80&w=2074&auto=format&fit=crop" alt="Location Map">
                        </div>
                    </div>
                    
                    <div class="contact-form-wrapper" data-aos="fade-left">
                        <form class="contact-form" id="contactForm">
                            <div class="form-group">
                                <label for="name">Your Name</label>
                                <input type="text" id="name" name="name" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="email">Email Address</label>
                                <input type="email" id="email" name="email" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="phone">Phone Number</label>
                                <input type="tel" id="phone" name="phone">
                            </div>
                            
                            <div class="form-group">
                                <label for="service">Service Interest</label>
                                <select id="service" name="service" required>
                                    <option value="">Select a service...</option>
                                    <option value="graphic-design">Graphic Designing</option>
                                    <option value="reels-editing">Reels Editing</option>
                                    <option value="video-editing">Video Editing</option>
                                    <option value="motion-graphics">Motion Graphics</option>
                                    <option value="content-research">Content Research</option>
                                    <option value="script-writing">Script Writing</option>
                                    <option value="social-media">Social Media Management</option>
                                    <option value="poster-design">Poster Design</option>
                                    <option value="full-package">Complete Package</option>
                                </select>
                            </div>
                            
                            <div class="form-group">
                                <label for="message">Your Message</label>
                                <textarea id="message" name="message" rows="5" required></textarea>
                            </div>
                            
                            <button type="submit" class="btn btn-primary btn-full">
                                Send Message
                                <i class="fas fa-paper-plane"></i>
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </section>

        <!-- CTA Banner -->
        <section class="cta-banner">
            <div class="cta-background">
                <img src="https://images.unsplash.com/photo-1558618666-fcd25c85cd64?q=80&w=2071&auto=format&fit=crop" alt="Work Together">
                <div class="cta-overlay"></div>
            </div>
            <div class="container cta-content" data-aos="zoom-in">
                <h2>Ready to Transform Your Brand?</h2>
                <p>Let's collaborate to create content that captivates, converts, and leaves a lasting impression.</p>
                <a href="#contact" class="btn btn-primary btn-large">
                    Work With Truth Arc Media
                    <i class="fas fa-arrow-right"></i>
                </a>
            </div>
        </section>

        <!-- Footer -->
        <footer class="footer">
            <div class="container">
                <div class="footer-grid">
                    <div class="footer-brand">
                        <div class="footer-logo">
                            <img src="/static/images/truth-arc-logo.png" alt="Truth Arc Media" class="footer-logo-image">
                        </div>
                        <p class="footer-tagline">
                            Crafting bold, cinematic content that inspires action and elevates brands.
                        </p>
                    </div>
                    
                    <div class="footer-links">
                        <h4>Quick Links</h4>
                        <ul>
                            <li><a href="#about">About Us</a></li>
                            <li><a href="#services">Services</a></li>
                            <li><a href="#portfolio">Our Work</a></li>
                            <li><a href="#process">Process</a></li>
                        </ul>
                    </div>
                    
                    <div class="footer-links">
                        <h4>Connect</h4>
                        <ul>
                            <li><a href="#team">Team</a></li>
                            <li><a href="#testimonials">Testimonials</a></li>
                            <li><a href="#contact">Contact Us</a></li>
                            <li><a href="https://instagram.com/trutharcmedia" target="_blank">Instagram</a></li>
                        </ul>
                    </div>
                    
                    <div class="footer-social">
                        <h4>Follow Us</h4>
                        <div class="social-icons">
                            <a href="https://instagram.com/trutharcmedia" target="_blank" aria-label="Instagram">
                                <i class="fab fa-instagram"></i>
                            </a>
                            <a href="https://facebook.com/trutharcmedia" target="_blank" aria-label="Facebook">
                                <i class="fab fa-facebook"></i>
                            </a>
                            <a href="https://linkedin.com/company/trutharcmedia" target="_blank" aria-label="LinkedIn">
                                <i class="fab fa-linkedin"></i>
                            </a>
                            <a href="https://youtube.com/trutharcmedia" target="_blank" aria-label="YouTube">
                                <i class="fab fa-youtube"></i>
                            </a>
                        </div>
                    </div>
                </div>
                
                <div class="footer-bottom">
                    <p>&copy; 2025 Truth Arc Media. All rights reserved.</p>
                    <p>Designed with <i class="fas fa-heart"></i> for bold brands</p>
                </div>
            </div>
        </footer>

        <!-- AOS Animation Library -->
        <script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js"></script>
        
        <!-- Custom JavaScript -->
        <script src="/static/js/main.js"></script>
    </body>
    </html>
  `)
})

export default app
