# Truth Arc Media - Premium Creative Digital Agency Portfolio

A modern, cinematic, and premium portfolio website for Truth Arc Media, showcasing creative services, work portfolio, team, and client testimonials.

## 🎨 Project Overview

**Name:** Truth Arc Media Portfolio  
**Type:** Creative Digital Agency Portfolio Website  
**Status:** ✅ Live & Running  
**Tech Stack:** Hono + Cloudflare Pages + Vanilla JavaScript  

## 🌐 Live URLs

- **Sandbox Development:** https://3000-igok3macphtuxscbrm29d-cc2fbc16.sandbox.novita.ai
- **Production:** (Deploy to Cloudflare Pages for production URL)

## ✨ Features Completed

### 🏠 Hero Section
- ✅ Full-screen hero image with cinematic overlay
- ✅ Bold headline with gradient text effect
- ✅ Primary and secondary CTA buttons
- ✅ Vision card with icon overlay
- ✅ Smooth scroll indicator with animation
- ✅ Parallax scrolling effect on background image

### 🧩 About Section
- ✅ Two-column layout with professional image
- ✅ Agency story and philosophy
- ✅ "Why Choose Us?" with 4 animated benefits
- ✅ Premium quality, fast turnaround, strategic approach, personalized service

### 🛠 Services Section (8 Services)
1. ✅ Graphic Designing
2. ✅ Reels Editing
3. ✅ Video Editing
4. ✅ Motion Graphics
5. ✅ Content Research
6. ✅ Script Writing
7. ✅ Social Media Management
8. ✅ Poster Design

Each service card includes:
- High-quality image
- Icon with gradient background
- Service description
- Hover animations (scale-up + gradient overlay)

### 🎬 Portfolio Section
- ✅ 6 featured projects in masonry grid
- ✅ Professional project images
- ✅ Hover overlay with project details
- ✅ Project categories and descriptions
- ✅ Interactive hover effects with zoom

### ⚙️ Process Section
- ✅ 4-step visual timeline
- ✅ Research & Discovery
- ✅ Creative Concept
- ✅ Production & Editing
- ✅ Optimization & Delivery
- ✅ Gradient connector lines
- ✅ Process images for each step
- ✅ Scroll-triggered animations

### 👥 Team Section
- ✅ 3 team members with professional photos
- ✅ Alex Rivera - Creative Director
- ✅ Maya Chen - Lead Video Editor
- ✅ Jordan Blake - Senior Designer
- ✅ Social media links (Instagram, LinkedIn)
- ✅ Hover effects with social icons overlay
- ✅ Team description highlighting collaboration

### ⭐ Testimonials Section
- ✅ 6 client testimonials
- ✅ 5-star ratings for each testimonial
- ✅ Client photos with professional portraits
- ✅ Instagram handles for each client
- ✅ Hover animations and card effects

### 📸 Instagram Section
- ✅ 6 Instagram post thumbnails
- ✅ Asymmetrical masonry grid layout
- ✅ Hover zoom with Instagram icon overlay
- ✅ "Follow Us on Instagram" CTA with pulse animation
- ✅ Clickable posts linking to Instagram

### 📞 Contact Section
- ✅ Modern contact form with validation
- ✅ Fields: Name, Email, Phone, Service dropdown, Message
- ✅ Clickable email and Instagram handle
- ✅ Location map image
- ✅ Form submission with success notification
- ✅ Interactive form validation

### 💡 CTA Banner
- ✅ Full-width call-to-action before footer
- ✅ Bold headline and supporting text
- ✅ Primary CTA button with hover effects
- ✅ Background image with emerald-to-black gradient overlay

### 🧾 Footer
- ✅ Agency logo and tagline
- ✅ Quick navigation links (4 columns)
- ✅ Social media icons (Instagram, Facebook, LinkedIn, YouTube)
- ✅ Copyright notice
- ✅ Professional footer design

### 🎯 Interactive Features
- ✅ Smooth scroll navigation with offset
- ✅ Sticky navigation bar with scroll effects
- ✅ Mobile-responsive hamburger menu
- ✅ Hero parallax scrolling
- ✅ AOS (Animate On Scroll) animations throughout
- ✅ Service card hover animations
- ✅ Portfolio item zoom effects
- ✅ Team card social overlay
- ✅ Testimonial card hover effects
- ✅ Instagram grid interactions
- ✅ Contact form with success notifications
- ✅ Floating WhatsApp button with float animation
- ✅ Scroll-to-top button
- ✅ Active nav link highlighting

## 🎨 Design System

### Color Palette
- **Emerald Green:** `#10b981` (Primary CTA, highlights)
- **Emerald Dark:** `#059669` (Hover states)
- **Cream:** `#faf8f5` (Backgrounds)
- **Cream Dark:** `#f5f3ef` (Alternate backgrounds)
- **Charcoal:** `#1a1a1a` (Typography)
- **Black:** `#0a0a0a` (Deep overlays)

### Typography
- **Headings:** Playfair Display (Serif, Bold, Elegant)
- **Body:** Inter (Sans-serif, Clean, Modern)

### Effects & Animations
- Smooth transitions (0.3s cubic-bezier)
- Gradient overlays (Emerald → Black, Cream → Emerald)
- Box shadows with layered depth
- Parallax scrolling on hero
- AOS animations on scroll
- Hover scale and rotate effects

## 📁 Project Structure

```
webapp/
├── src/
│   └── index.tsx          # Main Hono application with full HTML
├── public/
│   └── static/
│       ├── css/
│       │   └── styles.css # Premium CSS with color scheme
│       └── js/
│           └── main.js    # Interactive JavaScript
├── dist/                  # Built files (generated)
├── ecosystem.config.cjs   # PM2 configuration
├── package.json           # Dependencies and scripts
├── vite.config.ts         # Vite configuration
├── wrangler.jsonc         # Cloudflare configuration
└── README.md              # This file
```

## 🚀 Development

### Start Development Server
```bash
# Build project first
npm run build

# Start with PM2
pm2 start ecosystem.config.cjs

# Check status
pm2 list

# View logs
pm2 logs trutharc-media --nostream

# Test locally
curl http://localhost:3000
```

### Restart Server
```bash
# Clean port first
npm run clean-port

# Rebuild if needed
npm run build

# Restart
pm2 restart trutharc-media
```

## 📦 Deployment

### Deploy to Cloudflare Pages

1. **Setup Cloudflare API Key (Required):**
   - Configure API key through the Deploy tab
   - Or use `wrangler login`

2. **Build the Project:**
   ```bash
   npm run build
   ```

3. **Create Cloudflare Pages Project:**
   ```bash
   npx wrangler pages project create trutharc-media \
     --production-branch main \
     --compatibility-date 2024-01-01
   ```

4. **Deploy:**
   ```bash
   npm run deploy:prod
   ```

5. **Set Environment Variables (if needed):**
   ```bash
   npx wrangler pages secret put API_KEY --project-name trutharc-media
   ```

## 🎯 Key Sections & URIs

### Main Navigation
- `/` - Home/Hero
- `/#about` - About Section
- `/#services` - Services Grid (8 services)
- `/#portfolio` - Portfolio/Work Showcase (6 projects)
- `/#process` - 4-Step Process Timeline
- `/#team` - Team Members (3 people)
- `/#testimonials` - Client Testimonials (6 testimonials)
- `/#instagram` - Instagram Feed (6 posts)
- `/#contact` - Contact Form & Details

### Static Assets
- `/static/css/styles.css` - Main stylesheet
- `/static/js/main.js` - Interactive JavaScript
- All images are hosted via Unsplash CDN

## 🖼️ Images & Media

All images are sourced from Unsplash with high-quality professional photos:
- **Hero Background:** Creative studio workspace
- **About Image:** Team collaboration
- **Service Cards:** Industry-specific imagery (8 different images)
- **Portfolio Projects:** Creative work samples (6 projects)
- **Process Steps:** Visual representations (4 step images)
- **Team Photos:** Professional headshots (3 members)
- **Testimonials:** Client portraits (6 clients)
- **Instagram Grid:** Social media content (6 posts)
- **CTA Banner:** Cinematic background
- **Contact Map:** Location visualization

## 🔧 Technologies Used

- **Framework:** Hono (Lightweight edge framework)
- **Runtime:** Cloudflare Workers
- **Build Tool:** Vite
- **Process Manager:** PM2
- **Animations:** AOS (Animate On Scroll)
- **Icons:** Font Awesome 6
- **Fonts:** Google Fonts (Playfair Display + Inter)
- **Images:** Unsplash (High-quality stock photos)

## 📱 Responsive Design

- ✅ Desktop (1280px+): Full grid layouts
- ✅ Tablet (768px-1024px): Adjusted grids
- ✅ Mobile (320px-767px): Stacked layouts
- ✅ Mobile menu with hamburger toggle
- ✅ Responsive typography with `clamp()`
- ✅ Touch-friendly buttons and interactions

## 🎓 Best Practices Implemented

- ✅ Semantic HTML structure
- ✅ CSS custom properties for theming
- ✅ Mobile-first responsive design
- ✅ Performance optimized (lazy loading, debouncing)
- ✅ Accessibility considerations
- ✅ Clean, maintainable code structure
- ✅ Git version control with meaningful commits
- ✅ Comprehensive documentation

## 🔜 Future Enhancements

### Not Yet Implemented
- [ ] Backend API for form submissions
- [ ] Live Instagram feed integration
- [ ] Blog/News section
- [ ] Case studies with detailed project pages
- [ ] Multi-language support
- [ ] Dark mode toggle
- [ ] Advanced animations (GSAP)
- [ ] Video backgrounds
- [ ] Custom cursor trail (optional, commented out)
- [ ] Admin panel for content management

### Recommended Next Steps

1. **Form Backend:**
   - Integrate with email service (SendGrid, Mailgun)
   - Add form validation on server-side
   - Store submissions in database

2. **Instagram API:**
   - Connect to Instagram Graph API
   - Fetch real posts dynamically
   - Update feed automatically

3. **Content Management:**
   - Add CMS (Contentful, Sanity)
   - Make portfolio items editable
   - Dynamic testimonials management

4. **Analytics & SEO:**
   - Add Google Analytics
   - Implement SEO meta tags
   - Create sitemap.xml
   - Add Open Graph tags

5. **Performance:**
   - Implement image optimization
   - Add service worker for PWA
   - Enable caching strategies

## 📞 Contact & Social

- **Email:** hello@trutharcmedia.com
- **Instagram:** [@trutharcmedia](https://instagram.com/trutharcmedia)
- **WhatsApp:** +1 (234) 567-890

## 📝 License

© 2025 Truth Arc Media. All rights reserved.

---

**Built with 💚 for bold brands**

*A premium creative digital agency portfolio showcasing the power of modern web design and interactive storytelling.*
