# Our Work - Balanced 3-Column Portfolio Page

## 🎯 DESIGN PHILOSOPHY
Generous whitespace, clear visual rhythm, intentional separation between sections, calm confident composition. Visuals breathe with purpose. No clutter. Strong left-right balance with no empty right side.

---

## 📐 LAYOUT SPECIFICATIONS

### Global Layout Grid
- **Max content width**: 1320px
- **Side padding**: 64px (4rem)
- **Grid gap**: 48px (3rem)
- **Section spacing**: 140–180px (11.25rem between sections)
- **Background**: #0B0B0B / #111111
- **Accent color**: #00D9A3
- **Typography**: Modern sans-serif, bold headings, clean body

### Layout Balance Rules
✅ **Equal visual weight left and right**  
✅ **Larger project cards occupy space naturally**  
✅ **Intentional negative space, not blank space**  
✅ **No narrow columns hugging left edge**  
✅ **Right column includes at least one large card**

---

## 🎬 SECTION 1 — HERO INTRO

**Height**: 65vh  
**Content**: Centered text block constrained to 60% width  
**Background**: Dark charcoal (#111111) with subtle diagonal accent  
**Typography**:
- **H1**: "Our Work" — 6rem, font-weight 900
- **Subtitle**: "A showcase of creative excellence..." — 1.175rem, soft white (68% opacity)
- **Spacing**: 2rem between heading and subtitle

**Visual Elements**:
- Gradient overlay from top-left
- Diagonal green accent on right side (5% opacity)
- Symmetric padding and alignment

---

## 🎥 SECTION 2 — FEATURED VIDEO

**Purpose**: The ONLY full-width element on the page  
**Spacing**: 180px (11.25rem) above and below  
**Video specs**:
- Width: 100% of 1320px container
- Aspect ratio: 16:9
- Border radius: 16px
- Shadow: Multi-layer with green glow

**Overlay Content** (bottom-left, 48px padding):
- Badge: "FEATURED CASE STUDY" (green, small caps)
- Title: "Brand Revolution Campaign" (3.25rem, bold)
- Client: "TechStart Inc." (soft gray)
- Description: One-line impact statement
- CTA: "Watch Full Case Study" (solid green button)

**Interaction**:
- Autoplay muted loop
- Subtle hover effects
- Green glow shadow

---

## 📊 SECTION 3 — BALANCED 3-COLUMN MOSAIC GRID

### Grid Structure
**12-column CSS Grid** with automatic row height of 220px  
**Gap**: 3rem (48px)  
**Max width**: 1320px

### Card Layout Strategy (LEFT–CENTER–RIGHT BALANCE)

#### LEFT COLUMN (4 columns)
**Event Highlight Reel** - Tall Card
- Grid: 1 / span 4
- Rows: 1 / span 3
- Size: 4 columns × 3 rows
- Featured with larger typography

#### CENTER COLUMN (5 columns for wide, 2+3 for bottom)
**Product Launch Video** - Wide Card
- Grid: 5 / span 5
- Rows: 1 / span 2
- Size: 5 columns × 2 rows
- Dominant horizontal presence

**Restaurant Brand Identity** - Compact Card
- Grid: 5 / span 2
- Row: 3 / span 1
- Size: 2 columns × 1 row

**Animated Explainer Series** - Medium Card
- Grid: 7 / span 3
- Row: 3 / span 1
- Size: 3 columns × 1 row

#### RIGHT COLUMN (3 columns)
**Social Media Takeover** - Large Vertical Card ⭐
- Grid: 10 / span 3
- Rows: 1 / span 3
- Size: 3 columns × 3 rows
- Green accent border (2px solid #00D9A3)
- Includes performance metric: "300% engagement increase in 90 days"
- "View Project" button

### Visual Weight Distribution
- **Left**: 33.3% (4/12 columns) — Tall featured card
- **Center**: 41.7% (5/12 columns) — Wide card + 2 medium
- **Right**: 25% (3/12 columns) — Large vertical card with accent

**Result**: Balanced, no empty right side, strong visual hierarchy

---

## 🎨 PROJECT CARD DESIGN

### Card Components
**Top to bottom**:
1. Full-coverage background image
2. Dark gradient overlay (bottom to top)
3. Category label (green, small caps)
4. Project title (bold white, 1.625rem)
5. Client name (soft gray)
6. Optional result text (light white)
7. Optional CTA button

### Card Styling
- **Background**: #111111
- **Border radius**: 14px
- **Padding**: 2rem (32px)
- **Shadow**: Soft 10px/30px with 50% opacity
- **Hover**: 
  - Lift 10px
  - Enhanced shadow with green glow
  - Image zoom 1.06×

### Featured Cards (Larger Typography)
- **Large Right** (Social Media): 1.875rem heading
- **Tall Left** (Event Highlight): 1.875rem heading

---

## 🎯 SPACING & RHYTHM RULES

### Vertical Spacing
- **Section spacing**: 180px (11.25rem) between major sections
- **Card internal padding**: 32px (2rem)
- **Hero to video**: 180px
- **Video to grid**: 180px

### Horizontal Spacing
- **Side padding**: 64px (4rem)
- **Grid gap**: 48px (3rem)
- **No edge-to-edge elements** except featured video

### Typography Spacing
- **Line height**: 1.4–1.6
- **Heading to subtitle**: 2rem
- **Text elements**: Generous breathing room

---

## 📱 RESPONSIVE BEHAVIOR

### Desktop (>1024px)
- 12-column grid with balanced 3-column layout
- Video dominant at full width
- All cards display with intended sizes

### Tablet (768px–1024px)
- 8-column grid
- 2-column layout preserving visual weight
- Video remains prominent
- Cards reflow to maintain hierarchy

### Mobile (<768px)
- Single column stack
- Featured video at top (full-width, tap-to-play)
- Cards stack with varied heights:
  - Tall Left: 420px
  - Large Right: 440px
  - Wide Center: 380px
  - Compact Center: 320px
  - Medium Center: 360px
- No overlay clutter
- Simplified text

---

## 🎬 INTERACTIONS & MOTION

### Video Interactions
- Autoplay muted on page load
- Fade-in animation (AOS)
- Smooth hover transitions

### Card Interactions
- Staggered entrance (AOS with delays: 100ms, 200ms, 300ms, 350ms, 400ms)
- Hover lift (10px translateY)
- Green glow on hover
- Image zoom (1.06× scale)
- Button hover states

### Scroll Behavior
- Smooth scrolling
- Cards animate into view
- Refined, professional motion

---

## 🎨 COLOR SYSTEM

### Background Colors
- **Page background**: #0B0B0B
- **Hero section**: #111111
- **Cards**: #111111

### Accent Colors
- **Primary accent**: #00D9A3 (emerald green)
- **Button hover**: #00b087

### Text Colors
- **Headings**: #FFFFFF (white)
- **Body text**: rgba(255, 255, 255, 0.68–0.77)
- **Secondary text**: rgba(255, 255, 255, 0.58–0.62)

---

## ✅ QUALITY CHECKLIST

- [x] 65vh hero with centered text (60% width)
- [x] Diagonal accent on hero background
- [x] ONE full-width element (featured video)
- [x] 180px spacing above and below video
- [x] 16:9 video aspect ratio
- [x] Multi-layer green glow on video
- [x] Bottom-left overlay with 48px padding
- [x] "FEATURED CASE STUDY" badge
- [x] "Brand Revolution Campaign" title
- [x] "Watch Full Case Study" CTA button
- [x] Balanced 3-column grid (12 columns, 220px rows)
- [x] Left column: Tall card (Event Highlight Reel)
- [x] Center column: Wide card + 2 medium cards
- [x] Right column: Large vertical card (Social Media Takeover)
- [x] Green accent border on featured card
- [x] Performance metric text displayed
- [x] "View Project" button on featured card
- [x] 48px grid gap
- [x] 64px side padding
- [x] No right-side emptiness
- [x] Equal left-right visual weight
- [x] Intentional negative space
- [x] Larger confident cards
- [x] 14px border radius on cards
- [x] 32px card padding
- [x] Hover lift and green glow
- [x] Image zoom on hover (1.06×)
- [x] Smooth scrolling
- [x] Staggered card entrances (AOS)
- [x] Fully responsive (Desktop/Tablet/Mobile)
- [x] Mobile: varied card heights (no uniformity)
- [x] Git committed
- [x] Comprehensive documentation

---

## 📂 TECHNICAL IMPLEMENTATION

### Files Modified
1. **src/index.tsx** — HTML structure with balanced grid
2. **public/static/css/styles.css** — Complete CSS redesign

### Key CSS Classes
- `.balanced-work-page` — Main container
- `.balanced-hero` — Hero section (65vh)
- `.balanced-featured-video` — Video showcase
- `.balanced-mosaic` — Grid container
- `.balanced-grid` — 12-column CSS Grid
- `.tall-left` — Left column card
- `.wide-center` — Center wide card
- `.compact-center` — Center compact card
- `.medium-center` — Center medium card
- `.large-right` — Right column featured card

### Grid Layout CSS
```css
.balanced-grid {
    display: grid;
    grid-template-columns: repeat(12, 1fr);
    grid-auto-rows: 220px;
    gap: 3rem;
}

/* Left: 4 columns */
.tall-left {
    grid-column: 1 / span 4;
    grid-row: 1 / span 3;
}

/* Center: 5 columns wide + 2+3 bottom */
.wide-center {
    grid-column: 5 / span 5;
    grid-row: 1 / span 2;
}

/* Right: 3 columns */
.large-right {
    grid-column: 10 / span 3;
    grid-row: 1 / span 3;
}
```

---

## 🚀 LIVE PREVIEW

**URL**: https://3000-igok3macphtuxscbrm29d-cc2fbc16.sandbox.novita.ai

**To view**:
1. Open the URL in your browser
2. Scroll to "Our Work" section
3. Experience the balanced 3-column layout

---

## 📊 COMPARISON: BEFORE vs AFTER

### BEFORE (Previous Mosaic)
❌ Uneven left-right weight  
❌ Right side felt empty  
❌ No clear visual hierarchy  
❌ Cards felt random  

### AFTER (Balanced 3-Column)
✅ **Strong left-right balance**  
✅ **Right column has large featured card**  
✅ **Clear visual hierarchy** (Left tall, Center wide, Right large)  
✅ **Intentional negative space**  
✅ **Generous breathing room** (180px section spacing)  
✅ **Confident larger cards**  
✅ **Premium agency feel**  

---

## 🎯 USER EXPERIENCE GOALS

### Achieved Goals
1. **Calm but powerful**: Generous spacing creates confidence
2. **Cinematic yet readable**: Large video hero, clean typography
3. **Spacious yet intentional**: Every gap has purpose
4. **Premium studio feel**: Professional, polished, high-value
5. **Slow deliberate scrolling**: Users pause and absorb content
6. **Balanced composition**: No visual weight imbalance
7. **Clear hierarchy**: Video → Featured cards → Standard cards

---

## 📝 PROJECT STATUS

**Status**: ✅ **COMPLETE & LIVE**

**Deliverables**:
- ✅ Fully replaced "Our Work" page
- ✅ URL preserved (#portfolio)
- ✅ 65vh hero with centered text
- ✅ ONE full-width featured video
- ✅ Balanced 3-column mosaic (5 cards)
- ✅ Strong left-right visual weight
- ✅ No right-side emptiness
- ✅ Generous spacing (180px between sections)
- ✅ Grid gap 48px
- ✅ Side padding 64px
- ✅ Fully responsive
- ✅ Smooth animations
- ✅ Git committed
- ✅ Documentation created

**Live URL**: https://3000-igok3macphtuxscbrm29d-cc2fbc16.sandbox.novita.ai

---

## 🎬 FINAL EXPERIENCE

**Users will experience**:
- A calm, confident entry with 65vh hero
- ONE dominant featured video with cinematic presence
- A balanced 3-column project grid with strong left-right weight
- Generous breathing space (180px between sections)
- Larger confident project cards that command attention
- Smooth staggered animations as they scroll
- A premium creative agency aesthetic
- Clear visual hierarchy: Video > Featured projects > Standard projects
- No empty right side — balanced composition throughout

**Result**: A professional, spacious, intentionally designed portfolio page that reflects premium creative agency values with perfect visual balance.
